# -*- coding: utf-8 -*-

from . import product
from . import sale_order
from . import sale_rental
from . import stock
