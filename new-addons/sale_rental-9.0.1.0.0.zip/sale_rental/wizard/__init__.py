# -*- coding: utf-8 -*-

from . import create_rental_product
